<div class="absoluteCenter"><div><div>
<h1><?php echo $_GET['title']?></h1>
<div class="button gateway" data-view="beta" data-vars="?title=Beta">Next</div>
<div class="button gateway" data-view="main">Back Home</div>
</div></div></div>