<div class="absoluteCenter"><div><div>
<h1><?php echo $_GET['title']?></h1>
<div class="button gateway" data-view="gamma" data-vars="?title=Gamma">Next</div>
<div class="button gateway" data-view="main">Back Home</div>
</div></div></div>