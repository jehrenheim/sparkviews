<div class="absoluteCenter"><div><div>
<h1>Main View</h1>
<div class="button gateway" data-view="alpha" data-vars="?title=Alpha from Main">Go To Alpha</div>
<div class="button gateway" data-view="beta" data-vars="?title=Beta from Main">Go To Beta</div>
<div class="button gateway" data-view="gamma" data-vars="?title=Gamma from Main">Go To Gamma</div>
</div></div></div>